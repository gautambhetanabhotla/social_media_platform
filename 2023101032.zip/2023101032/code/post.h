#include "types.h"

#ifndef POST_H
#define POST_H

Post* createPost(char* username, char* caption);

#endif
