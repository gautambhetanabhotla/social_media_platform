#include "types.h"

#ifndef COMMENT_H
#define COMMENT_H

Comment* createComment(char* username, char* content);

#endif
