#include "types.h"

#ifndef REPLY_H
#define REPLY_H

Reply* createReply(char* username, char* content);

#endif
